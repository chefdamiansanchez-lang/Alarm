# Alarma

Alarmas (por dia, con sonido y voz), cronometro y temporizador. Colores suaves y solidos.

1. Subi todo el contenido al repositorio de GitHub (la carpeta .github/workflows/build.yml incluida).
2. En la pestana Actions se compila solo.
3. El APK queda en Releases (descarga directa desde el movil) y en Artifacts.
