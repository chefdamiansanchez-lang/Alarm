package com.alarma.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val type = intent.getStringExtra("type") ?: "alarm"
        val id = intent.getIntExtra("id", 0)
        var label = "Temporizador terminado"
        var sound = 0
        var voice = false

        if (type == "alarm") {
            val list = Store.load(context).toMutableList()
            val idx = list.indexOfFirst { it.id == id }
            if (idx < 0) return
            val a = list[idx]
            label = "Alarma"
            sound = a.sound
            voice = a.voice
            if (a.days != 0) {
                Scheduler.schedule(context, a)
            } else {
                list[idx] = a.copy(enabled = false)
                Store.save(context, list)
            }
        } else {
            Store.setTimerEnd(context, 0L)
        }

        val si = Intent(context, AlarmService::class.java)
            .putExtra("label", label)
            .putExtra("sound", sound)
            .putExtra("voice", voice)
        try {
            ContextCompat.startForegroundService(context, si)
        } catch (e: Exception) {
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Scheduler.rescheduleAll(context)
        }
    }
}
