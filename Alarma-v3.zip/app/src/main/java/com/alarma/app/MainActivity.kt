package com.alarma.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private val alarms = mutableStateListOf<AlarmItem>()
    private var timerEnd by mutableLongStateOf(0L)

    private val perms = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { cacheLocation() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val need = mutableListOf<String>()
        if (!granted(Manifest.permission.ACCESS_COARSE_LOCATION)) need.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isNotEmpty()) perms.launch(need.toTypedArray())

        setContent {
            AlarmaTheme {
                MainScreen(
                    alarms = alarms,
                    onSaveAlarm = { saveAlarm(it) },
                    onDeleteAlarm = { deleteAlarm(it) },
                    onToggle = { a, on -> toggle(a, on) },
                    timerEnd = timerEnd,
                    onTimerStart = { end ->
                        Store.setTimerEnd(this, end)
                        timerEnd = end
                        Scheduler.scheduleTimer(this, end)
                    },
                    onTimerCancel = {
                        Store.setTimerEnd(this, 0L)
                        timerEnd = 0L
                        Scheduler.cancelTimer(this)
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        alarms.clear()
        alarms.addAll(Store.load(this))
        timerEnd = Store.getTimerEnd(this)
        cacheLocation()
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun cacheLocation() {
        if (!granted(Manifest.permission.ACCESS_COARSE_LOCATION)) return
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var best: android.location.Location? = null
            for (p in lm.getProviders(true)) {
                val l = lm.getLastKnownLocation(p) ?: continue
                if (best == null || l.time > best.time) best = l
            }
            if (best != null) Store.setLoc(this, best.latitude, best.longitude)
            if (Build.VERSION.SDK_INT >= 30 && lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.getCurrentLocation(LocationManager.NETWORK_PROVIDER, null, mainExecutor) { l ->
                    if (l != null) Store.setLoc(this, l.latitude, l.longitude)
                }
            }
        } catch (e: Exception) {
        }
    }

    private fun persist() = Store.save(this, alarms.toList())

    private fun saveAlarm(a: AlarmItem) {
        val item = if (a.id == 0) a.copy(id = Store.nextId(this)) else a
        val idx = alarms.indexOfFirst { it.id == item.id }
        if (idx >= 0) alarms[idx] = item else alarms.add(item)
        persist()
        announce(Scheduler.schedule(this, item))
    }

    private fun deleteAlarm(a: AlarmItem) {
        Scheduler.cancel(this, a.id)
        alarms.removeAll { it.id == a.id }
        persist()
    }

    private fun toggle(a: AlarmItem, on: Boolean) {
        val item = a.copy(enabled = on)
        val idx = alarms.indexOfFirst { it.id == a.id }
        if (idx >= 0) alarms[idx] = item
        persist()
        announce(Scheduler.schedule(this, item))
    }

    private fun announce(at: Long) {
        if (at <= 0L) return
        val mins = ((at - System.currentTimeMillis()) / 60000L).coerceAtLeast(0L)
        val d = mins / 1440
        val h = (mins % 1440) / 60
        val m = mins % 60
        val txt = buildString {
            append("Suena en ")
            if (d > 0) append("$d d ")
            if (h > 0 || d > 0) append("$h h ")
            append("$m min")
        }
        Toast.makeText(this, txt, Toast.LENGTH_SHORT).show()
    }
}
