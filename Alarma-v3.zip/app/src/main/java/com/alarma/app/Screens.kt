package com.alarma.app

import android.os.SystemClock
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalTime
import java.util.Locale

private fun f(fmt: String, vararg a: Any): String = String.format(Locale.US, fmt, *a)

// ---------- piezas comunes ----------

@Composable
fun ScreenTitle(text: String) {
    Text(
        text, color = C.Ink, fontSize = 26.sp, fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center,
        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
    )
}

@Composable
fun SectionLabel(text: String) {
    Text(
        text, color = C.Muted, fontSize = 14.sp,
        modifier = Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 6.dp)
    )
}

@Composable
fun Btn(
    text: String,
    modifier: Modifier = Modifier,
    primary: Boolean = true,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.height(52.dp),
        shape = RoundedCornerShape(16.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (primary) C.Accent else C.Surface2,
            contentColor = if (primary) C.OnAccent else C.Ink,
            disabledContainerColor = C.Surface,
            disabledContentColor = C.Muted
        )
    ) {
        Text(text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
    }
}

@Composable
fun RepeatButton(text: String, onStep: () -> Unit) {
    val scope = rememberCoroutineScope()
    val cur = rememberUpdatedState(onStep)
    Box(
        Modifier
            .size(52.dp)
            .clip(CircleShape)
            .background(C.Surface2)
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    cur.value()
                    val job = scope.launch {
                        delay(400)
                        while (true) {
                            cur.value()
                            delay(90)
                        }
                    }
                    tryAwaitRelease()
                    job.cancel()
                })
            },
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = C.Accent, fontSize = 24.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Stepper(value: Int, max: Int, unit: String, onChange: (Int) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(84.dp)) {
        RepeatButton("+") { onChange((value + 1) % (max + 1)) }
        Text(
            f("%02d", value), color = C.Ink, fontSize = 44.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(vertical = 6.dp)
        )
        RepeatButton("−") { onChange((value + max) % (max + 1)) }
        Text(unit, color = C.Muted, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

// ---------- pantalla principal ----------

class StopwatchState {
    var running by mutableStateOf(false)
    var base by mutableLongStateOf(0L)
    var startedAt by mutableLongStateOf(0L)
    val laps = mutableStateListOf<Long>()

    fun elapsed(now: Long): Long = if (running) base + (now - startedAt) else base

    fun toggle() {
        if (running) {
            base = elapsed(SystemClock.elapsedRealtime())
            running = false
        } else {
            startedAt = SystemClock.elapsedRealtime()
            running = true
        }
    }

    fun lap() {
        laps.add(0, elapsed(SystemClock.elapsedRealtime()))
    }

    fun reset() {
        running = false
        base = 0L
        laps.clear()
    }
}

@Composable
fun MainScreen(
    alarms: SnapshotStateList<AlarmItem>,
    onSaveAlarm: (AlarmItem) -> Unit,
    onDeleteAlarm: (AlarmItem) -> Unit,
    onToggle: (AlarmItem, Boolean) -> Unit,
    timerEnd: Long,
    onTimerStart: (Long) -> Unit,
    onTimerCancel: () -> Unit
) {
    var tab by remember { mutableIntStateOf(0) }
    val sw = remember { StopwatchState() }
    val icons = listOf("⏰", "⏱️", "⌛")
    val names = listOf("Alarmas", "Cronómetro", "Temporizador")

    Scaffold(
        containerColor = C.Bg,
        bottomBar = {
            NavigationBar(containerColor = C.Surface) {
                names.forEachIndexed { i, n ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(icons[i], fontSize = 22.sp) },
                        label = { Text(n, fontSize = 12.sp, maxLines = 1, softWrap = false) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedTextColor = C.Accent,
                            unselectedTextColor = C.Muted,
                            selectedIconColor = C.Accent,
                            unselectedIconColor = C.Muted,
                            indicatorColor = C.Surface2
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> AlarmsScreen(alarms, onSaveAlarm, onDeleteAlarm, onToggle)
                1 -> StopwatchScreen(sw)
                else -> TimerScreen(timerEnd, onTimerStart, onTimerCancel)
            }
        }
    }
}

// ---------- alarmas ----------

private val DAY_SHORT = listOf("Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom")

private fun daysText(days: Int): String = when {
    days == 0 -> "Una sola vez"
    days == 127 -> "Todos los días"
    else -> DAY_SHORT.filterIndexed { i, _ -> ((days shr i) and 1) == 1 }.joinToString(" ")
}

@Composable
fun AlarmsScreen(
    alarms: SnapshotStateList<AlarmItem>,
    onSave: (AlarmItem) -> Unit,
    onDelete: (AlarmItem) -> Unit,
    onToggle: (AlarmItem, Boolean) -> Unit
) {
    var editing by remember { mutableStateOf<AlarmItem?>(null) }
    BackHandler(enabled = editing != null) { editing = null }

    val e = editing
    if (e != null) {
        key(e.id) {
            AlarmEditor(
                initial = e,
                onSave = { onSave(it); editing = null },
                onDelete = { onDelete(e); editing = null },
                onCancel = { editing = null }
            )
        }
    } else {
        val sorted = alarms.sortedWith(compareBy({ it.hour }, { it.minute }))
        Column(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ScreenTitle("Alarmas")
            if (sorted.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("No hay alarmas todavía", color = C.Muted, fontSize = 16.sp)
                }
            } else {
                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(sorted, key = { it.id }) { a ->
                        AlarmCard(a, onClick = { editing = a }, onToggle = { onToggle(a, it) })
                    }
                }
            }
            Btn(
                "+ Nueva alarma",
                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
            ) { editing = AlarmItem() }
        }
    }
}

@Composable
fun AlarmCard(a: AlarmItem, onClick: () -> Unit, onToggle: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(C.Surface)
            .clickable { onClick() }
            .padding(horizontal = 18.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                f("%02d:%02d", a.hour, a.minute),
                color = if (a.enabled) C.Ink else C.Muted,
                fontSize = 38.sp, fontWeight = FontWeight.Medium
            )
            Text(daysText(a.days), color = C.Muted, fontSize = 14.sp)
        }
        Switch(
            checked = a.enabled,
            onCheckedChange = onToggle,
            colors = SwitchDefaults.colors(
                checkedTrackColor = C.Accent,
                checkedThumbColor = C.OnAccent,
                uncheckedTrackColor = C.Surface2,
                uncheckedThumbColor = C.Muted,
                uncheckedBorderColor = C.Muted
            )
        )
    }
}

@Composable
fun AlarmEditor(
    initial: AlarmItem,
    onSave: (AlarmItem) -> Unit,
    onDelete: () -> Unit,
    onCancel: () -> Unit
) {
    var h by remember { mutableIntStateOf(initial.hour) }
    var m by remember { mutableIntStateOf(initial.minute) }
    var days by remember { mutableIntStateOf(initial.days) }
    var sound by remember { mutableIntStateOf(initial.sound) }
    var voice by remember { mutableStateOf(initial.voice) }
    val isNew = initial.id == 0

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ScreenTitle(if (isNew) "Nueva alarma" else "Editar alarma")
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Stepper(h, 23, "hora") { h = it }
            Text(":", color = C.Ink, fontSize = 44.sp, modifier = Modifier.padding(bottom = 28.dp, start = 8.dp, end = 8.dp))
            Stepper(m, 59, "min") { m = it }
        }

        SectionLabel("Repetir")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            listOf("L", "M", "X", "J", "V", "S", "D").forEachIndexed { i, n ->
                val on = ((days shr i) and 1) == 1
                Box(
                    Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(if (on) C.Accent else C.Surface2)
                        .clickable { days = days xor (1 shl i) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(n, color = if (on) C.OnAccent else C.Ink, fontWeight = FontWeight.Bold)
                }
            }
        }
        Text(
            if (days == 0) "Suena una sola vez" else daysText(days),
            color = C.Muted, fontSize = 13.sp,
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
        )

        SectionLabel("Sonido")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Alarma", "Tono", "Aviso").forEachIndexed { i, n ->
                Btn(n, modifier = Modifier.weight(1f), primary = sound == i) { sound = i }
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Voz al sonar", color = C.Ink, fontSize = 16.sp)
                Text("Dice el día, la hora y el clima", color = C.Muted, fontSize = 13.sp)
            }
            Switch(
                checked = voice,
                onCheckedChange = { voice = it },
                colors = SwitchDefaults.colors(
                    checkedTrackColor = C.Accent,
                    checkedThumbColor = C.OnAccent,
                    uncheckedTrackColor = C.Surface2,
                    uncheckedThumbColor = C.Muted,
                    uncheckedBorderColor = C.Muted
                )
            )
        }

        Spacer(Modifier.height(24.dp))
        Btn("Guardar", modifier = Modifier.fillMaxWidth().height(56.dp)) {
            onSave(initial.copy(hour = h, minute = m, days = days, sound = sound, voice = voice, enabled = true))
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Btn("Cancelar", modifier = Modifier.weight(1f), primary = false) { onCancel() }
            if (!isNew) Btn("Eliminar", modifier = Modifier.weight(1f), primary = false) { onDelete() }
        }
        Spacer(Modifier.height(16.dp))
    }
}

// ---------- cronómetro ----------

private fun fmtStopwatch(ms: Long): String {
    val cs = (ms / 10) % 100
    val s = (ms / 1000) % 60
    val m = (ms / 60000) % 60
    val h = ms / 3600000
    return if (h > 0) f("%d:%02d:%02d.%02d", h, m, s, cs) else f("%02d:%02d.%02d", m, s, cs)
}

@Composable
fun StopwatchScreen(sw: StopwatchState) {
    var now by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(sw.running) {
        while (sw.running) {
            now = SystemClock.elapsedRealtime()
            delay(30)
        }
        now = SystemClock.elapsedRealtime()
    }
    val ms = sw.elapsed(now)

    Column(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ScreenTitle("Cronómetro")
        Spacer(Modifier.height(32.dp))
        Text(
            fmtStopwatch(ms), color = C.Ink, fontSize = 54.sp, fontWeight = FontWeight.Medium,
            maxLines = 1, softWrap = false
        )
        Spacer(Modifier.height(32.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            if (sw.running) {
                Btn("Vuelta", modifier = Modifier.width(140.dp), primary = false) { sw.lap() }
            } else {
                Btn("Reiniciar", modifier = Modifier.width(140.dp), primary = false, enabled = sw.base > 0L) { sw.reset() }
            }
            Btn(if (sw.running) "Pausar" else "Iniciar", modifier = Modifier.width(140.dp)) { sw.toggle() }
        }
        Spacer(Modifier.height(20.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            items(sw.laps.size) { i ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 8.dp, horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Vuelta ${sw.laps.size - i}", color = C.Muted, fontSize = 16.sp)
                    Text(fmtStopwatch(sw.laps[i]), color = C.Ink, fontSize = 16.sp)
                }
            }
        }
    }
}

// ---------- temporizador ----------

private fun fmtTimer(ms: Long): String {
    val total = (ms + 999) / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) f("%d:%02d:%02d", h, m, s) else f("%02d:%02d", m, s)
}

@Composable
fun TimerScreen(timerEnd: Long, onStart: (Long) -> Unit, onCancel: () -> Unit) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(200)
        }
    }
    val remaining = timerEnd - now

    var h by remember { mutableIntStateOf(0) }
    var m by remember { mutableIntStateOf(1) }
    var s by remember { mutableIntStateOf(0) }

    Column(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ScreenTitle("Temporizador")
        Spacer(Modifier.weight(1f))
        if (remaining > 0) {
            Text(
                fmtTimer(remaining), color = C.Ink, fontSize = 64.sp, fontWeight = FontWeight.Medium,
                maxLines = 1, softWrap = false
            )
            Spacer(Modifier.height(32.dp))
            Btn("Cancelar", modifier = Modifier.width(200.dp), primary = false) { onCancel() }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                Stepper(h, 23, "h") { h = it }
                Text(":", color = C.Ink, fontSize = 40.sp, modifier = Modifier.padding(bottom = 28.dp))
                Stepper(m, 59, "min") { m = it }
                Text(":", color = C.Ink, fontSize = 40.sp, modifier = Modifier.padding(bottom = 28.dp))
                Stepper(s, 59, "s") { s = it }
            }
            Spacer(Modifier.height(24.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1, 5, 10, 30).forEach { q ->
                    Btn("$q min", modifier = Modifier.weight(1f), primary = false) {
                        h = q / 60; m = q % 60; s = 0
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
            Btn("Iniciar", modifier = Modifier.fillMaxWidth().height(56.dp)) {
                val total = (h * 3600L + m * 60L + s) * 1000L
                if (total > 0L) onStart(System.currentTimeMillis() + total)
            }
        }
        Spacer(Modifier.weight(1f))
    }
}

// ---------- pantalla de alarma sonando ----------

@Composable
fun RingScreen(label: String, onStop: () -> Unit) {
    var time by remember { mutableStateOf(LocalTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            time = LocalTime.now()
            delay(1000)
        }
    }
    Column(
        Modifier.fillMaxSize().background(C.Bg).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(f("%02d:%02d", time.hour, time.minute), color = C.Ink, fontSize = 72.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(8.dp))
        Text(label, color = C.Accent, fontSize = 22.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(48.dp))
        Btn("Detener", modifier = Modifier.fillMaxWidth().height(64.dp)) { onStop() }
    }
}
