package com.alarma.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object C {
    val Bg = Color(0xFF232833)
    val Surface = Color(0xFF2E3441)
    val Surface2 = Color(0xFF3A4252)
    val Accent = Color(0xFF9CCBB8)
    val OnAccent = Color(0xFF1E2A26)
    val Ink = Color(0xFFE9EDF2)
    val Muted = Color(0xFF9AA4B2)
}

@Composable
fun AlarmaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = C.Accent,
            onPrimary = C.OnAccent,
            background = C.Bg,
            onBackground = C.Ink,
            surface = C.Surface,
            onSurface = C.Ink,
            surfaceVariant = C.Surface2,
            onSurfaceVariant = C.Muted
        ),
        content = content
    )
}
