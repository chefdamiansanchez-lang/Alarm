package com.alarma.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

class AlarmService : Service(), TextToSpeech.OnInitListener {

    companion object {
        @Volatile
        var running = false
        const val ACTION_STOP = "com.alarma.app.STOP"
        const val CHANNEL = "alarma_sonando"
        const val NOTIF_ID = 77
    }

    private val handler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private var vibrator: Vibrator? = null
    private var speech: String? = null

    private val repeatSpeech = object : Runnable {
        override fun run() {
            speech?.let { speak(it) }
            handler.postDelayed(this, 45000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        val label = intent?.getStringExtra("label") ?: "Alarma"
        val sound = intent?.getIntExtra("sound", 0) ?: 0
        val voice = intent?.getBooleanExtra("voice", false) ?: false

        createChannel()
        val n = buildNotification(label)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, n)
        }

        startSound(sound)
        startVibration()
        if (voice) tts = TextToSpeech(this, this)

        handler.postDelayed({ stopSelf() }, 5 * 60 * 1000L)
        return START_NOT_STICKY
    }

    private fun attrs(): AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ALARM)
        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
        .build()

    private fun createChannel() {
        val ch = NotificationChannel(CHANNEL, "Alarma sonando", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(null, null)
        ch.enableVibration(false)
        ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun buildNotification(label: String): Notification {
        val ring = PendingIntent.getActivity(
            this, 1,
            Intent(this, RingActivity::class.java)
                .putExtra("label", label)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 2,
            Intent(this, AlarmService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(label)
            .setContentText("Toca para abrir o detener")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setFullScreenIntent(ring, true)
            .setContentIntent(ring)
            .addAction(0, "Detener", stop)
            .setOngoing(true)
            .build()
    }

    private fun startSound(sound: Int) {
        try {
            val type = when (sound) {
                1 -> RingtoneManager.TYPE_RINGTONE
                2 -> RingtoneManager.TYPE_NOTIFICATION
                else -> RingtoneManager.TYPE_ALARM
            }
            val uri = RingtoneManager.getActualDefaultRingtoneUri(this, type)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            val mp = MediaPlayer()
            mp.setAudioAttributes(attrs())
            mp.setDataSource(this, uri)
            mp.isLooping = true
            mp.prepare()
            mp.start()
            player = mp
        } catch (e: Exception) {
        }
    }

    private fun startVibration() {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            vibrator = v
            v?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 700), 0))
        } catch (e: Exception) {
        }
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val t = tts ?: return
        if (t.setLanguage(Locale("es", "AR")) < 0) t.setLanguage(Locale("es"))
        t.setAudioAttributes(attrs())
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                handler.post { player?.setVolume(0.25f, 0.25f) }
            }

            override fun onDone(utteranceId: String?) {
                handler.post { player?.setVolume(1f, 1f) }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                handler.post { player?.setVolume(1f, 1f) }
            }
        })
        Thread {
            val weather = fetchWeather()
            val text = buildSpeech(weather)
            handler.post {
                if (running) {
                    speech = text
                    handler.post(repeatSpeech)
                }
            }
        }.start()
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "msg")
    }

    private fun buildSpeech(weather: String?): String {
        val now = LocalTime.now()
        val h = now.hour
        val m = now.minute
        val greet = when {
            h < 12 -> "Buenos días"
            h < 20 -> "Buenas tardes"
            else -> "Buenas noches"
        }
        val date = LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE d 'de' MMMM", Locale("es", "AR")))
        val h12 = if (h % 12 == 0) 12 else h % 12
        val part = when (h) {
            in 0..5 -> "de la madrugada"
            in 6..11 -> "de la mañana"
            in 12..19 -> "de la tarde"
            else -> "de la noche"
        }
        val start = if (h12 == 1) "Es la una" else "Son las $h12"
        val mins = if (m == 0) "en punto" else "y $m"
        return "$greet. Hoy es $date. $start $mins $part. ${weather ?: ""}"
    }

    private fun fetchWeather(): String? {
        return try {
            val loc = Store.getLoc(this) ?: return null
            val url = URL(
                "https://api.open-meteo.com/v1/forecast?latitude=${loc.first}&longitude=${loc.second}" +
                    "&current=temperature_2m,weather_code&timezone=auto"
            )
            val c = url.openConnection() as HttpURLConnection
            c.connectTimeout = 4000
            c.readTimeout = 4000
            val cur = JSONObject(c.inputStream.bufferedReader().readText()).getJSONObject("current")
            val t = cur.getDouble("temperature_2m").roundToInt()
            val code = cur.getInt("weather_code")
            "Afuera hay $t grados, ${describe(code)}."
        } catch (e: Exception) {
            null
        }
    }

    private fun describe(code: Int): String = when (code) {
        0 -> "cielo despejado"
        1, 2, 3 -> "parcialmente nublado"
        45, 48 -> "con niebla"
        in 51..57 -> "con llovizna"
        in 61..67 -> "con lluvia"
        in 71..77 -> "con nieve"
        in 80..82 -> "con chubascos"
        in 95..99 -> "con tormenta"
        else -> "clima variable"
    }

    private fun cleanup() {
        handler.removeCallbacksAndMessages(null)
        try {
            player?.stop()
        } catch (e: Exception) {
        }
        player?.release()
        player = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        vibrator?.cancel()
    }

    override fun onDestroy() {
        running = false
        cleanup()
        super.onDestroy()
    }
}
