package com.alarma.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.ZoneId

/** days: bits 0..6 = lunes..domingo. 0 = suena una sola vez. sound: 0 alarma, 1 tono, 2 aviso */
data class AlarmItem(
    val id: Int = 0,
    val hour: Int = 7,
    val minute: Int = 0,
    val days: Int = 0,
    val enabled: Boolean = true,
    val sound: Int = 0,
    val voice: Boolean = true
)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("alarma", Context.MODE_PRIVATE)

    fun load(c: Context): List<AlarmItem> {
        val out = mutableListOf<AlarmItem>()
        try {
            val arr = JSONArray(p(c).getString("alarms", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    AlarmItem(
                        o.getInt("id"), o.getInt("hour"), o.getInt("minute"), o.getInt("days"),
                        o.getBoolean("enabled"), o.getInt("sound"), o.getBoolean("voice")
                    )
                )
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun save(c: Context, list: List<AlarmItem>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id).put("hour", it.hour).put("minute", it.minute)
                    .put("days", it.days).put("enabled", it.enabled)
                    .put("sound", it.sound).put("voice", it.voice)
            )
        }
        p(c).edit().putString("alarms", arr.toString()).apply()
    }

    fun nextId(c: Context): Int {
        val n = p(c).getInt("nextId", 1)
        p(c).edit().putInt("nextId", n + 1).apply()
        return n
    }

    fun getTimerEnd(c: Context): Long = p(c).getLong("timerEnd", 0L)
    fun setTimerEnd(c: Context, v: Long) {
        p(c).edit().putLong("timerEnd", v).apply()
    }

    fun setLoc(c: Context, lat: Double, lon: Double) {
        p(c).edit().putString("lat", lat.toString()).putString("lon", lon.toString()).apply()
    }

    fun getLoc(c: Context): Pair<Double, Double>? {
        val la = p(c).getString("lat", null)?.toDoubleOrNull() ?: return null
        val lo = p(c).getString("lon", null)?.toDoubleOrNull() ?: return null
        return Pair(la, lo)
    }
}

object Scheduler {
    private fun am(c: Context) = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun pi(c: Context, id: Int, type: String): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java).putExtra("type", type).putExtra("id", id)
        return PendingIntent.getBroadcast(
            c, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun setAt(c: Context, at: Long, p: PendingIntent) {
        val show = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        try {
            am(c).setAlarmClock(AlarmManager.AlarmClockInfo(at, show), p)
        } catch (e: SecurityException) {
            am(c).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
        }
    }

    fun nextTrigger(a: AlarmItem, from: LocalDateTime = LocalDateTime.now()): Long {
        for (offset in 0..7) {
            val date = from.toLocalDate().plusDays(offset.toLong())
            val dt = date.atTime(a.hour, a.minute)
            if (!dt.isAfter(from)) continue
            val bit = (a.days shr (date.dayOfWeek.value - 1)) and 1
            if (a.days == 0 || bit == 1) {
                return dt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
            }
        }
        return from.plusDays(1).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
    }

    /** Programa la alarma. Devuelve la hora (ms) o 0 si esta apagada. */
    fun schedule(c: Context, a: AlarmItem): Long {
        if (!a.enabled) {
            cancel(c, a.id)
            return 0L
        }
        val at = nextTrigger(a)
        setAt(c, at, pi(c, a.id, "alarm"))
        return at
    }

    fun cancel(c: Context, id: Int) {
        am(c).cancel(pi(c, id, "alarm"))
    }

    fun scheduleTimer(c: Context, end: Long) {
        setAt(c, end, pi(c, 0, "timer"))
    }

    fun cancelTimer(c: Context) {
        am(c).cancel(pi(c, 0, "timer"))
    }

    fun rescheduleAll(c: Context) {
        Store.load(c).filter { it.enabled }.forEach { schedule(c, it) }
        val e = Store.getTimerEnd(c)
        if (e > System.currentTimeMillis()) scheduleTimer(c, e)
    }
}
