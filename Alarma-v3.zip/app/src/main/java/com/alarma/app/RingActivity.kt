package com.alarma.app

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent

class RingActivity : ComponentActivity() {
    private val h = Handler(Looper.getMainLooper())
    private val check = object : Runnable {
        override fun run() {
            if (!AlarmService.running) finish() else h.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val label = intent.getStringExtra("label") ?: "Alarma"
        setContent {
            AlarmaTheme {
                RingScreen(label) {
                    stopService(Intent(this@RingActivity, AlarmService::class.java))
                    finish()
                }
            }
        }
        h.postDelayed(check, 1500)
    }

    override fun onDestroy() {
        h.removeCallbacks(check)
        super.onDestroy()
    }
}
